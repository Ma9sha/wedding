<!DOCTYPE html>
<html>
<head>
    <title>Radha & Surya wedding page</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <header class="">
    <a href="/" class="">
    </a>
    <ul class="menu">
        <li><a href="/" class="nav-link px-2 link-secondary">Home</a></li>
        <li><a href="/events/garba.php" class="nav-link px-2 link-dark">Garba</a></li>
        <li><a href="/events/mehandi.php" class="nav-link px-2 link-dark">Mehandi</a></li>
        <li><a href="/events/vidhi.php" class="nav-link px-2 link-dark">Vidhi</a></li>
        <li><a href="/events/reception.php" class="nav-link px-2 link-dark">Reception</a></li>
    </ul>
    <!-- <div class="col-md-3 text-end">
    <button type="button" class="btn btn-outline-primary me-2">Login</button>
    <button type="button" class="btn btn-primary">Sign-up</button>
    </div> -->
    </header>
</div>